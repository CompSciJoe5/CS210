// Name Clock_H
// Author Jose Munoz
// Date: 5-26-24

#ifndef CLOCK_H
#define CLOCK_H

#include <iostream>
#include <iomanip>
#include <string>

class Clock {
private:
    int hour;
    int minute;
    int second;

public:
    Clock(int h = 0, int m = 0, int s = 0);
    void addHour();
    void addMinute();
    void addSecond();
    void display12HourFormat() const;
    void display24HourFormat() const;
};

#endif
