// Name .h
// Author Jose Munoz
// Date: 5-26-24

#include "Clock.h"

Clock::Clock(int h, int m, int s)
    : hour(h), minute(m), second(s) {}

void Clock::addHour() {
    hour = (hour + 1) % 24;
}

void Clock::addMinute() {
    minute = (minute + 1) % 60;
    if (minute == 0) addHour();
}

void Clock::addSecond() {
    second = (second + 1) % 60;
    if (second == 0) addMinute();
}

void Clock::display12HourFormat() const {
    int displayHour = hour % 12;
    if (displayHour == 0) displayHour = 12;
    std::string period = (hour < 12) ? "AM" : "PM";
    std::cout << std::setw(2) << std::setfill('0') << displayHour << ":"
              << std::setw(2) << std::setfill('0') << minute << ":"
              << std::setw(2) << std::setfill('0') << second << " " << period << std::endl;
}

void Clock::display24HourFormat() const {
    std::cout << std::setw(2) << std::setfill('0') << hour << ":"
              << std::setw(2) << std::setfill('0') << minute << ":"
              << std::setw(2) << std::setfill('0') << second << std::endl;
}
